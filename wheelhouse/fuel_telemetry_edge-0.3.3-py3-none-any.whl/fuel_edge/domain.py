"""Núcleo de control local, autorización y habilitación de bomba."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import StrEnum
from typing import Any
from uuid import uuid4

from .access import AccessContext, AccessPolicy
from .relay import MemoryPumpRelay, PumpRelay


class EdgeState(StrEnum):
    UNASSIGNED = "unassigned"
    LOCKED = "locked"
    VALIDATING = "validating"
    AUTHORIZED = "authorized"
    DISPENSING = "dispensing"
    CLOSING = "closing"
    FAULT = "fault"


class EdgeEvent(StrEnum):
    ASSIGN = "assign"
    NFC_PRESENTED = "nfc_presented"
    AUTHORIZATION_GRANTED = "authorization_granted"
    AUTHORIZATION_DENIED = "authorization_denied"
    NFC_REJECTED = "nfc_rejected"
    FLOW_STARTED = "flow_started"
    FLOW_STOPPED = "flow_stopped"
    NFC_REMOVED = "nfc_removed"
    BLE_LOST = "ble_lost"
    START_TIMEOUT = "start_timeout"
    CLOSE_CONFIRMED = "close_confirmed"
    TELEMETRY_FAULT = "telemetry_fault"
    TELEMETRY_RESTORED = "telemetry_restored"
    VALIDATOR_LINK_LOST = "validator_link_lost"
    VALIDATOR_LINK_RESTORED = "validator_link_restored"
    CONTROL_FAULT = "control_fault"
    RESET = "reset"


class InvalidTransition(ValueError):
    """El evento no es válido en el estado actual."""


@dataclass(frozen=True, slots=True)
class AuditRecord:
    occurred_at: datetime
    previous_state: EdgeState
    event: EdgeEvent
    new_state: EdgeState
    relay_energized: bool
    metadata: dict[str, Any]


@dataclass(frozen=True, slots=True)
class ControlConfig:
    start_timeout_seconds: int = 60
    k24_inactivity_seconds: int = 20
    ble_loss_seconds: int = 20
    nfc_debounce_milliseconds: int = 300
    nfc_presence_timeout_milliseconds: int = 2500


@dataclass(slots=True)
class FuelEdgeMachine:
    """Decide localmente la habilitación y siempre corta ante fallas de control."""

    relay: PumpRelay = field(default_factory=MemoryPumpRelay)
    access_policy: AccessPolicy = field(default_factory=AccessPolicy)
    config: ControlConfig = field(default_factory=ControlConfig)
    state: EdgeState = EdgeState.UNASSIGNED
    module_id: str | None = None
    site_id: str | None = None
    transaction_id: str | None = None
    operator_id: str | None = None
    equipment_id: str | None = None
    authorized_at: datetime | None = None
    last_pulse_at: datetime | None = None
    pulse_count: int = 0
    validator_online: bool = True
    k24_healthy: bool = True
    audit: list[AuditRecord] = field(default_factory=list)

    _TRANSITIONS = {
        (EdgeState.UNASSIGNED, EdgeEvent.ASSIGN): EdgeState.LOCKED,
        (EdgeState.LOCKED, EdgeEvent.NFC_PRESENTED): EdgeState.VALIDATING,
        (EdgeState.VALIDATING, EdgeEvent.AUTHORIZATION_GRANTED): EdgeState.AUTHORIZED,
        (EdgeState.VALIDATING, EdgeEvent.AUTHORIZATION_DENIED): EdgeState.LOCKED,
        (EdgeState.VALIDATING, EdgeEvent.NFC_REJECTED): EdgeState.LOCKED,
        (EdgeState.AUTHORIZED, EdgeEvent.FLOW_STARTED): EdgeState.DISPENSING,
        (EdgeState.AUTHORIZED, EdgeEvent.NFC_REMOVED): EdgeState.CLOSING,
        (EdgeState.AUTHORIZED, EdgeEvent.BLE_LOST): EdgeState.CLOSING,
        (EdgeState.AUTHORIZED, EdgeEvent.START_TIMEOUT): EdgeState.CLOSING,
        (EdgeState.DISPENSING, EdgeEvent.FLOW_STOPPED): EdgeState.CLOSING,
        (EdgeState.DISPENSING, EdgeEvent.NFC_REMOVED): EdgeState.CLOSING,
        (EdgeState.DISPENSING, EdgeEvent.BLE_LOST): EdgeState.CLOSING,
        (EdgeState.CLOSING, EdgeEvent.CLOSE_CONFIRMED): EdgeState.LOCKED,
        (EdgeState.FAULT, EdgeEvent.RESET): EdgeState.LOCKED,
        (EdgeState.LOCKED, EdgeEvent.VALIDATOR_LINK_LOST): EdgeState.LOCKED,
        (EdgeState.VALIDATING, EdgeEvent.VALIDATOR_LINK_LOST): EdgeState.LOCKED,
        (EdgeState.AUTHORIZED, EdgeEvent.VALIDATOR_LINK_LOST): EdgeState.CLOSING,
        (EdgeState.DISPENSING, EdgeEvent.VALIDATOR_LINK_LOST): EdgeState.CLOSING,
        (EdgeState.LOCKED, EdgeEvent.VALIDATOR_LINK_RESTORED): EdgeState.LOCKED,
        (EdgeState.AUTHORIZED, EdgeEvent.VALIDATOR_LINK_RESTORED): EdgeState.AUTHORIZED,
        (EdgeState.DISPENSING, EdgeEvent.VALIDATOR_LINK_RESTORED): EdgeState.DISPENSING,
    }

    def __post_init__(self) -> None:
        # El arranque siempre deja el circuito de mando abierto.
        self.relay.deenergize()

    def present_credential(self, credential_id: str) -> AuditRecord:
        if not self.validator_online:
            raise RuntimeError("validator offline: no se admiten nuevas cargas")
        return self.apply(EdgeEvent.NFC_PRESENTED, credential_id=credential_id)

    def authorize(self, context: AccessContext) -> AuditRecord:
        if self.state is not EdgeState.VALIDATING:
            return self._invalid(EdgeEvent.AUTHORIZATION_GRANTED)

        decision = self.access_policy.evaluate(context)
        metadata = {
            "credential_id": context.credential_id,
            "operator_id": context.operator_id,
            "equipment_id": context.equipment_id,
            "is_master": context.is_master,
        }
        if not decision.allowed:
            metadata["reason"] = str(decision.reason)
            return self.apply(EdgeEvent.AUTHORIZATION_DENIED, **metadata)

        transaction_id = str(uuid4())
        authorized_at = datetime.now(timezone.utc)
        try:
            self.relay.energize()
            if not self.relay.is_energized:
                raise RuntimeError("relay did not confirm energized state")
        except Exception as exc:
            # Se intenta LOW incluso si la orden HIGH devolvió error; _enter_fault
            # vuelve a intentarlo para no ocultar una falla de corte persistente.
            try:
                self.relay.deenergize()
            except Exception:
                pass
            return self._enter_fault("relay_enable_failed", error=type(exc).__name__)

        self.operator_id = context.operator_id
        self.equipment_id = context.equipment_id
        self.transaction_id = transaction_id
        self.authorized_at = authorized_at
        self.last_pulse_at = None
        self.pulse_count = 0
        metadata["transaction_id"] = transaction_id
        metadata["start_timeout_seconds"] = self.config.start_timeout_seconds
        return self.apply(EdgeEvent.AUTHORIZATION_GRANTED, **metadata)

    def record_k24_pulse(self, count: int = 1, at: datetime | None = None) -> AuditRecord | None:
        if count <= 0:
            raise ValueError("count debe ser positivo")
        at = at or datetime.now(timezone.utc)
        if self.state not in {EdgeState.AUTHORIZED, EdgeState.DISPENSING}:
            return self.apply(
                EdgeEvent.TELEMETRY_FAULT,
                sensor="K24",
                reason="unauthorized_flow",
                pulse_count=count,
                critical=True,
            )
        record = None
        if self.state is EdgeState.AUTHORIZED:
            record = self.apply(EdgeEvent.FLOW_STARTED, first_pulse_at=at.isoformat())
        self.pulse_count += count
        self.last_pulse_at = at
        return record

    def check_timeouts(self, now: datetime | None = None) -> AuditRecord | None:
        now = now or datetime.now(timezone.utc)
        if self.state is EdgeState.AUTHORIZED and self.authorized_at is not None:
            deadline = self.authorized_at + timedelta(seconds=self.config.start_timeout_seconds)
            if now >= deadline:
                return self.apply(EdgeEvent.START_TIMEOUT, reason="no_flow_after_authorization")
        if self.state is EdgeState.DISPENSING and self.last_pulse_at is not None and self.k24_healthy:
            deadline = self.last_pulse_at + timedelta(seconds=self.config.k24_inactivity_seconds)
            if now >= deadline:
                return self.apply(
                    EdgeEvent.FLOW_STOPPED,
                    reason="k24_inactivity",
                    pulses=self.pulse_count,
                )
        return None

    def apply(self, event: EdgeEvent, **metadata: Any) -> AuditRecord:
        if event is EdgeEvent.CONTROL_FAULT:
            return self._enter_fault(str(metadata.pop("reason", "control_fault")), **metadata)
        if event is EdgeEvent.TELEMETRY_FAULT:
            if str(metadata.get("sensor", "")).upper() == "K24" and metadata.get("reason") != "unauthorized_flow":
                self.k24_healthy = False
            return self._record(event, self.state, metadata)
        if event is EdgeEvent.TELEMETRY_RESTORED:
            if str(metadata.get("sensor", "")).upper() == "K24":
                self.k24_healthy = True
            return self._record(event, self.state, metadata)

        if event is EdgeEvent.VALIDATOR_LINK_LOST:
            self.validator_online = False
        elif event is EdgeEvent.VALIDATOR_LINK_RESTORED:
            self.validator_online = True

        if event is EdgeEvent.RESET and not metadata.get("control_chain_healthy", False):
            raise ValueError("RESET requiere confirmación control_chain_healthy")
        if event is EdgeEvent.RESET and (not self.module_id or not self.site_id):
            raise ValueError("RESET no puede habilitar un punto sin asignación")

        try:
            new_state = self._TRANSITIONS[(self.state, event)]
        except KeyError:
            return self._invalid(event)

        if event is EdgeEvent.ASSIGN:
            module_id = metadata.get("module_id")
            site_id = metadata.get("site_id")
            if not module_id or not site_id:
                raise ValueError("ASSIGN requiere module_id y site_id")
            self.module_id = str(module_id)
            self.site_id = str(site_id)

        if event in {
            EdgeEvent.AUTHORIZATION_DENIED,
            EdgeEvent.NFC_REJECTED,
            EdgeEvent.NFC_REMOVED,
            EdgeEvent.BLE_LOST,
            EdgeEvent.START_TIMEOUT,
            EdgeEvent.FLOW_STOPPED,
            EdgeEvent.CLOSE_CONFIRMED,
            EdgeEvent.RESET,
            EdgeEvent.VALIDATOR_LINK_LOST,
        }:
            self.relay.deenergize()

        record = self._record(event, new_state, metadata)
        if new_state is EdgeState.LOCKED:
            self._clear_session()
        return record

    def _invalid(self, event: EdgeEvent) -> AuditRecord:
        previous_state = self.state
        if self.relay.is_energized:
            self._enter_fault("invalid_transition", attempted_event=str(event))
        raise InvalidTransition(f"{event} no es válido desde {previous_state}")

    def _enter_fault(self, reason: str, **metadata: Any) -> AuditRecord:
        self.relay.deenergize()
        metadata["reason"] = reason
        return self._record(EdgeEvent.CONTROL_FAULT, EdgeState.FAULT, metadata)

    def _record(self, event: EdgeEvent, new_state: EdgeState, metadata: dict[str, Any]) -> AuditRecord:
        record = AuditRecord(
            occurred_at=datetime.now(timezone.utc),
            previous_state=self.state,
            event=event,
            new_state=new_state,
            relay_energized=self.relay.is_energized,
            metadata=dict(metadata),
        )
        self.state = new_state
        self.audit.append(record)
        return record

    def _clear_session(self) -> None:
        self.transaction_id = None
        self.operator_id = None
        self.equipment_id = None
        self.authorized_at = None
        self.last_pulse_at = None
        self.pulse_count = 0

    @staticmethod
    def audit_payload(record: AuditRecord) -> dict[str, Any]:
        payload = asdict(record)
        payload["occurred_at"] = record.occurred_at.isoformat()
        payload["previous_state"] = str(record.previous_state)
        payload["event"] = str(record.event)
        payload["new_state"] = str(record.new_state)
        return payload
