"""Orquestación del núcleo, el relé y la persistencia local."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from math import isfinite
from threading import RLock
from time import monotonic
from typing import Callable

from .access import AccessContext
from .domain import AuditRecord, EdgeEvent, EdgeState, FuelEdgeMachine
from .storage import EventStore


@dataclass(frozen=True, slots=True)
class _TransactionSnapshot:
    transaction_id: str | None
    pulse_count: int


class FuelEdgeService:
    """Única puerta de entrada operacional al núcleo de control."""

    def __init__(
        self,
        machine: FuelEdgeMachine,
        store: EventStore,
        *,
        pulses_per_liter: float,
        k24_enabled: bool = True,
        tank_level_enabled: bool = True,
        validator_enabled: bool = True,
    ) -> None:
        if pulses_per_liter <= 0:
            raise ValueError("pulses_per_liter debe ser positivo")
        self.machine = machine
        self.store = store
        self.pulses_per_liter = pulses_per_liter
        self.k24_enabled = k24_enabled
        self.tank_level_enabled = tank_level_enabled
        self.validator_enabled = validator_enabled
        self._validator_reported_at: float | None = None
        self._nfc_ready = False
        self._lock = RLock()

    def report_validator_hardware(self, nfc_ready: bool) -> None:
        """Registra un heartbeat físico; un retained antiguo no queda sano para siempre."""
        with self._lock:
            self._nfc_ready = nfc_ready
            self._validator_reported_at = monotonic()

    def report_validator_offline(self) -> None:
        with self._lock:
            self._nfc_ready = False
            self._validator_reported_at = None

    def assign(self, module_id: str, site_id: str) -> AuditRecord:
        return self._execute(
            lambda: self.machine.apply(
                EdgeEvent.ASSIGN, module_id=module_id, site_id=site_id
            )
        )

    def present_credential(self, credential_id: str) -> AuditRecord:
        return self._execute(lambda: self.machine.present_credential(credential_id))

    def authorize(self, context: AccessContext) -> AuditRecord:
        with self._lock:
            record = self.machine.authorize(context)
            try:
                self._persist(record)
                if record.event is EdgeEvent.AUTHORIZATION_GRANTED:
                    if not self.machine.transaction_id or not self.machine.operator_id:
                        raise RuntimeError("autorización sin identidad de transacción")
                    self.store.open_transaction(
                        self.machine.transaction_id,
                        self.machine.operator_id,
                        self.machine.equipment_id,
                        context.is_master,
                        record.occurred_at.isoformat(),
                    )
            except Exception as exc:
                self._fail_safe_after_storage_error(exc)
            return record

    def apply(self, event: EdgeEvent, **metadata: object) -> AuditRecord:
        return self._execute(lambda: self.machine.apply(event, **metadata))

    def record_k24_pulse(
        self, count: int = 1, at: datetime | None = None
    ) -> AuditRecord | None:
        return self._execute_optional(lambda: self.machine.record_k24_pulse(count, at))

    def tick(self, now: datetime | None = None) -> AuditRecord | None:
        def advance() -> AuditRecord | None:
            # CLOSING representa el corte ya ordenado. La confirmación que
            # ofrece el adaptador es que el driver aceptó LOW; completar esta
            # transición evita que el punto quede ocupado indefinidamente.
            if self.machine.state is EdgeState.CLOSING:
                if self.machine.relay.is_energized:
                    return self.machine.apply(
                        EdgeEvent.CONTROL_FAULT,
                        reason="relay_remained_energized_during_close",
                    )
                return self.machine.apply(
                    EdgeEvent.CLOSE_CONFIRMED,
                    reason="relay_deenergized",
                )
            return self.machine.check_timeouts(now)

        return self._execute_optional(advance)

    def record_tank_level(
        self,
        level_liters: float,
        occurred_at: str,
        *,
        source: str = "OCIO",
    ) -> int:
        if not isfinite(level_liters) or level_liters < 0:
            raise ValueError("level_liters debe ser finito y no negativo")
        if not source or len(source) > 80:
            raise ValueError("source inválido")
        return self.store.enqueue_tank_level(
            level_liters=level_liters,
            occurred_at=occurred_at,
            source=source,
        )

    def publish_status(self) -> int:
        validator_online = bool(
            self.validator_enabled
            and self._validator_reported_at is not None
            and monotonic() - self._validator_reported_at <= 15.0
        )
        return self.store.enqueue_latest(
            "web/status",
            {
                "moduleId": self.machine.module_id,
                "siteId": self.machine.site_id,
                "state": str(self.machine.state),
                "relayEnergized": self.machine.relay.is_energized,
                "validatorOnline": validator_online,
                "nfcReady": validator_online and self._nfc_ready,
                "k24Enabled": self.k24_enabled,
                "k24Healthy": self.machine.k24_healthy,
                "tankLevelEnabled": self.tank_level_enabled,
                "occurredAt": datetime.now().astimezone().isoformat(),
            },
            "web/status:latest",
        )

    def _execute(self, operation: Callable[[], AuditRecord]) -> AuditRecord:
        record = self._execute_optional(operation)
        if record is None:  # pragma: no cover - contrato de Callable
            raise RuntimeError("la operación no produjo un registro")
        return record

    def _execute_optional(
        self, operation: Callable[[], AuditRecord | None]
    ) -> AuditRecord | None:
        with self._lock:
            before = _TransactionSnapshot(
                transaction_id=self.machine.transaction_id,
                pulse_count=self.machine.pulse_count,
            )
            record = operation()
            if record is None:
                return None
            try:
                self._persist(record)
                if (
                    before.transaction_id
                    and record.new_state in {EdgeState.CLOSING, EdgeState.FAULT}
                ):
                    pulses = self.machine.pulse_count
                    self.store.close_transaction(
                        before.transaction_id,
                        record.occurred_at.isoformat(),
                        str(record.metadata.get("reason", record.event)),
                        pulses,
                        pulses / self.pulses_per_liter,
                    )
            except Exception as exc:
                self._fail_safe_after_storage_error(exc)
            return record

    def _persist(self, record: AuditRecord) -> None:
        payload = self.machine.audit_payload(record)
        self.store.record_audit(payload)
        self.store.enqueue("edge/audit", payload)
        if record.event in {
            EdgeEvent.CONTROL_FAULT,
            EdgeEvent.TELEMETRY_FAULT,
            EdgeEvent.VALIDATOR_LINK_LOST,
            EdgeEvent.BLE_LOST,
        }:
            severity = "critical" if record.event in {EdgeEvent.CONTROL_FAULT, EdgeEvent.TELEMETRY_FAULT} else "warning"
            titles = {
                EdgeEvent.CONTROL_FAULT: "Falla de la cadena de control",
                EdgeEvent.TELEMETRY_FAULT: "Falla de telemetría",
                EdgeEvent.VALIDATOR_LINK_LOST: "Validador sin conexión",
                EdgeEvent.BLE_LOST: "Carga cerrada por pérdida BLE",
            }
            occurred_at = record.occurred_at.isoformat()
            self.store.enqueue(
                "web/alert",
                {
                    "id": f"edge-alert-{record.event}-{int(record.occurred_at.timestamp() * 1_000_000)}",
                    "severity": severity,
                    "title": titles[record.event],
                    "detail": str(record.metadata.get("reason", record.metadata.get("sensor", "Evento generado por el controlador edge"))),
                    "occurredAt": occurred_at,
                },
                dedupe_key=f"web/alert:{record.event}:{occurred_at}",
            )

    def _fail_safe_after_storage_error(self, error: Exception) -> None:
        """Un error de auditoría durante una carga abre el circuito y bloquea."""
        fault = self.machine.apply(
            EdgeEvent.CONTROL_FAULT,
            reason="persistence_failure",
            error=type(error).__name__,
        )
        try:
            self.store.record_audit(self.machine.audit_payload(fault))
        except Exception:
            pass
        raise RuntimeError("falló la persistencia local; relé desenergizado") from error
