"""Política local de identidad, presencia y autorización de carga."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum


class DenialReason(StrEnum):
    CREDENTIAL_INACTIVE = "credential_inactive"
    OPERATOR_INACTIVE = "operator_inactive"
    POINT_UNAVAILABLE = "point_unavailable"
    CONTROL_CHAIN_UNHEALTHY = "control_chain_unhealthy"
    EQUIPMENT_REQUIRED = "equipment_required"
    EQUIPMENT_INACTIVE = "equipment_inactive"
    EQUIPMENT_NOT_PRESENT = "equipment_not_present"
    EQUIPMENT_NOT_AUTHENTICATED = "equipment_not_authenticated"
    ASSOCIATION_INACTIVE = "association_inactive"
    ASSIGNMENT_EXPIRED = "assignment_expired"


@dataclass(frozen=True, slots=True)
class AccessContext:
    credential_id: str
    operator_id: str
    credential_active: bool
    operator_active: bool
    is_master: bool = False
    equipment_id: str | None = None
    equipment_active: bool = False
    equipment_present: bool = False
    equipment_authenticated: bool = False
    association_active: bool = False
    assignment_valid_until: datetime | None = None
    point_available: bool = True
    control_chain_healthy: bool = True


@dataclass(frozen=True, slots=True)
class AccessDecision:
    allowed: bool
    reason: DenialReason | None = None


class AccessPolicy:
    """Aplica las reglas que deben cumplirse antes de energizar el relé."""

    def evaluate(self, context: AccessContext, now: datetime | None = None) -> AccessDecision:
        now = now or datetime.now(timezone.utc)
        checks = (
            (context.credential_active, DenialReason.CREDENTIAL_INACTIVE),
            (context.operator_active, DenialReason.OPERATOR_INACTIVE),
            (context.point_available, DenialReason.POINT_UNAVAILABLE),
            (context.control_chain_healthy, DenialReason.CONTROL_CHAIN_UNHEALTHY),
        )
        for condition, reason in checks:
            if not condition:
                return AccessDecision(False, reason)

        if context.is_master:
            return AccessDecision(True)

        if not context.equipment_id:
            return AccessDecision(False, DenialReason.EQUIPMENT_REQUIRED)
        equipment_checks = (
            (context.equipment_active, DenialReason.EQUIPMENT_INACTIVE),
            (context.equipment_present, DenialReason.EQUIPMENT_NOT_PRESENT),
            (context.equipment_authenticated, DenialReason.EQUIPMENT_NOT_AUTHENTICATED),
            (context.association_active, DenialReason.ASSOCIATION_INACTIVE),
        )
        for condition, reason in equipment_checks:
            if not condition:
                return AccessDecision(False, reason)
        if context.assignment_valid_until is not None and context.assignment_valid_until <= now:
            return AccessDecision(False, DenialReason.ASSIGNMENT_EXPIRED)
        return AccessDecision(True)
