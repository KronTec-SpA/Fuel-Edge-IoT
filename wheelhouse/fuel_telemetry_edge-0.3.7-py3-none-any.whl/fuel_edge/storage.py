"""Persistencia local durable para auditoría, transacciones y sincronización."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from typing import Any


SCHEMA = """
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at TEXT NOT NULL,
    event TEXT NOT NULL,
    previous_state TEXT NOT NULL,
    new_state TEXT NOT NULL,
    relay_energized INTEGER NOT NULL CHECK (relay_energized IN (0, 1)),
    payload TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    operator_id TEXT NOT NULL,
    equipment_id TEXT,
    is_master INTEGER NOT NULL CHECK (is_master IN (0, 1)),
    opened_at TEXT NOT NULL,
    closed_at TEXT,
    close_reason TEXT,
    pulses INTEGER NOT NULL DEFAULT 0,
    liters REAL,
    status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS unauthorized_flow_incidents (
    id TEXT PRIMARY KEY,
    started_at TEXT NOT NULL,
    last_pulse_at TEXT NOT NULL,
    pulses INTEGER NOT NULL CHECK (pulses > 0),
    closed_at TEXT,
    liters REAL,
    status TEXT NOT NULL CHECK (status IN ('active', 'closed'))
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_unauthorized_flow_active
ON unauthorized_flow_incidents(status) WHERE status = 'active';

CREATE TABLE IF NOT EXISTS outbox (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT NOT NULL,
    payload TEXT NOT NULL,
    dedupe_key TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    sent_at TEXT,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TEXT,
    last_error TEXT,
    discarded_at TEXT
);

"""


def format_liters_cl(liters: float) -> str:
    """Formatea litros con punto de miles y coma decimal para Chile."""
    return f"{liters:,.3f}".translate(str.maketrans({",": ".", ".": ","}))


class EventStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        # MQTT entrega eventos desde un trabajador. El lock mantiene una sola
        # operación activa aunque la conexión se comparta entre hilos.
        self.connection = sqlite3.connect(self.path, check_same_thread=False)
        with self._lock:
            self.connection.execute("PRAGMA foreign_keys = ON")
            self.connection.execute("PRAGMA journal_mode = WAL")
            self.connection.execute("PRAGMA synchronous = FULL")
            self.connection.execute("PRAGMA busy_timeout = 5000")
            self.connection.executescript(SCHEMA)
            self._migrate_outbox()
            self.connection.commit()

    def record_audit(self, payload: dict[str, Any]) -> int:
        with self._lock:
            cursor = self.connection.execute(
                """
                INSERT INTO audit_log(
                    occurred_at, event, previous_state, new_state, relay_energized, payload
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    payload["occurred_at"],
                    payload["event"],
                    payload["previous_state"],
                    payload["new_state"],
                    int(payload["relay_energized"]),
                    json.dumps(
                        payload.get("metadata", {}),
                        separators=(",", ":"),
                        sort_keys=True,
                    ),
                ),
            )
            self.connection.commit()
            return int(cursor.lastrowid)

    def open_transaction(
        self,
        transaction_id: str,
        operator_id: str,
        equipment_id: str | None,
        is_master: bool,
        opened_at: str,
    ) -> None:
        with self._lock:
            self.connection.execute(
                """
                INSERT INTO transactions(id, operator_id, equipment_id, is_master, opened_at, status)
                VALUES (?, ?, ?, ?, ?, 'authorized')
                """,
                (transaction_id, operator_id, equipment_id, int(is_master), opened_at),
            )
            self.connection.commit()

    def close_transaction(
        self,
        transaction_id: str,
        closed_at: str,
        close_reason: str,
        pulses: int,
        liters: float | None,
    ) -> None:
        with self._lock:
            row = self.connection.execute(
                "SELECT operator_id, equipment_id, is_master, opened_at, status FROM transactions WHERE id = ?",
                (transaction_id,),
            ).fetchone()
            if row is None:
                raise LookupError(f"transacción desconocida: {transaction_id}")
            if row[4] == "closed":
                return
            cursor = self.connection.execute(
                """
                UPDATE transactions
                SET closed_at = ?, close_reason = ?, pulses = ?, liters = ?, status = 'closed'
                WHERE id = ? AND status != 'closed'
                """,
                (closed_at, close_reason, pulses, liters, transaction_id),
            )
            if cursor.rowcount != 1:
                raise RuntimeError("la transacción no pudo cerrarse de forma atómica")
            if liters is not None and liters > 0:
                payload = {
                    "id": transaction_id,
                    "type": "dispatch",
                    "occurredAt": closed_at,
                    "liters": round(float(liters), 3),
                    "source": "K24 + PLC",
                    "reference": transaction_id,
                    "detail": (
                        f"{row[0]} · Carga excepcional · Tarjeta maestra"
                        if bool(row[2])
                        else f"{row[0]} · {row[1] or 'Equipo no informado'}"
                    ),
                    "operatorId": row[0],
                    "equipmentId": row[1],
                    "isMaster": bool(row[2]),
                    "openedAt": row[3],
                    "closeReason": close_reason,
                    "pulses": pulses,
                }
                self.connection.execute(
                    "INSERT OR IGNORE INTO outbox(topic,payload,dedupe_key) VALUES (?,?,?)",
                    (
                        "web/fuel-movement",
                        self._encode_payload(payload),
                        f"web/fuel-movement:{transaction_id}",
                    ),
                )
            self.connection.commit()

    def active_unauthorized_flow(self) -> tuple[str, str, str, int] | None:
        with self._lock:
            row = self.connection.execute(
                """SELECT id,started_at,last_pulse_at,pulses
                FROM unauthorized_flow_incidents WHERE status='active' LIMIT 1"""
            ).fetchone()
            if row is None:
                return None
            return str(row[0]), str(row[1]), str(row[2]), int(row[3])

    def record_unauthorized_flow_pulses(
        self,
        incident_id: str,
        started_at: str,
        last_pulse_at: str,
        pulses: int,
    ) -> int:
        if not incident_id or pulses <= 0:
            raise ValueError("incidente y pulsos no autorizados deben ser válidos")
        with self._lock:
            self.connection.execute(
                """INSERT INTO unauthorized_flow_incidents(
                    id,started_at,last_pulse_at,pulses,status
                ) VALUES (?,?,?,?,'active')
                ON CONFLICT(id) DO UPDATE SET
                    last_pulse_at=excluded.last_pulse_at,
                    pulses=unauthorized_flow_incidents.pulses+excluded.pulses
                WHERE unauthorized_flow_incidents.status='active'""",
                (incident_id, started_at, last_pulse_at, pulses),
            )
            row = self.connection.execute(
                "SELECT pulses,status FROM unauthorized_flow_incidents WHERE id=?",
                (incident_id,),
            ).fetchone()
            if row is None or row[1] != "active":
                self.connection.rollback()
                raise RuntimeError("el incidente de flujo no autorizado no está activo")
            self.connection.commit()
            return int(row[0])

    def close_unauthorized_flow(
        self,
        incident_id: str,
        closed_at: str,
        pulses_per_liter: float,
    ) -> tuple[int, float]:
        if pulses_per_liter <= 0:
            raise ValueError("pulses_per_liter debe ser positivo")
        with self._lock:
            row = self.connection.execute(
                """SELECT started_at,last_pulse_at,pulses,status,liters
                FROM unauthorized_flow_incidents WHERE id=?""",
                (incident_id,),
            ).fetchone()
            if row is None:
                raise LookupError(f"incidente desconocido: {incident_id}")
            pulses = int(row[2])
            liters = float(row[4]) if row[4] is not None else pulses / pulses_per_liter
            if row[3] == "closed":
                return pulses, liters
            cursor = self.connection.execute(
                """UPDATE unauthorized_flow_incidents
                SET closed_at=?,liters=?,status='closed'
                WHERE id=? AND status='active'""",
                (closed_at, liters, incident_id),
            )
            if cursor.rowcount != 1:
                self.connection.rollback()
                raise RuntimeError("el incidente no pudo cerrarse de forma atómica")

            movement = {
                "id": incident_id,
                "type": "dispatch",
                "occurredAt": closed_at,
                "liters": round(liters, 3),
                "source": "K24 · Detección independiente",
                "reference": incident_id,
                "detail": (
                    "Flujo no autorizado · Sin operador ni equipo · "
                    "Posible bypass de bomba detectado por K24"
                ),
                "operatorId": None,
                "equipmentId": None,
                "isMaster": False,
                "unauthorized": True,
                "openedAt": row[0],
                "closeReason": "unauthorized_flow",
                "pulses": pulses,
            }
            alert = {
                "id": f"edge-alert-{incident_id}",
                "severity": "critical",
                "priority": "urgent",
                "title": "Flujo de petróleo sin autorización",
                "detail": (
                    f"K24 registró {pulses} pulsos ({format_liters_cl(liters)} L) "
                    "sin una "
                    "autorización activa. Posible bypass de la bomba."
                ),
                "occurredAt": row[0],
            }
            for topic, payload, dedupe_key in (
                (
                    "web/fuel-movement",
                    movement,
                    f"web/fuel-movement:{incident_id}",
                ),
                ("web/alert", alert, f"web/alert:{incident_id}"),
            ):
                self.connection.execute(
                    """INSERT INTO outbox(topic,payload,dedupe_key) VALUES (?,?,?)
                    ON CONFLICT(dedupe_key) DO UPDATE SET
                    topic=excluded.topic,payload=excluded.payload,
                    created_at=CURRENT_TIMESTAMP,sent_at=NULL,attempt_count=0,
                    next_attempt_at=NULL,last_error=NULL,discarded_at=NULL""",
                    (topic, self._encode_payload(payload), dedupe_key),
                )
            self.connection.commit()
            return pulses, liters

    def enqueue(
        self,
        topic: str,
        payload: dict[str, Any],
        *,
        dedupe_key: str | None = None,
    ) -> int:
        if not topic or len(topic) > 120:
            raise ValueError("topic inválido")
        encoded = self._encode_payload(payload)
        with self._lock:
            cursor = self.connection.execute(
                "INSERT OR IGNORE INTO outbox(topic,payload,dedupe_key) VALUES (?,?,?)",
                (topic, encoded, dedupe_key),
            )
            if cursor.rowcount == 0 and dedupe_key is not None:
                existing = self.connection.execute(
                    "SELECT id FROM outbox WHERE dedupe_key = ?", (dedupe_key,)
                ).fetchone()
                if existing is None:
                    raise RuntimeError("no se pudo recuperar el evento idempotente")
                self.connection.commit()
                return int(existing[0])
            self.connection.commit()
            return int(cursor.lastrowid)

    def enqueue_tank_level(
        self,
        *,
        level_liters: float,
        occurred_at: str,
        source: str = "OCIO",
    ) -> int:
        return self.enqueue(
            "web/level-reading",
            {
                "levelLiters": round(level_liters, 3),
                "occurredAt": occurred_at,
                "source": source,
            },
            dedupe_key=f"web/level-reading:{occurred_at}",
        )

    def enqueue_latest(self, topic: str, payload: dict[str, Any], dedupe_key: str) -> int:
        if not topic or not dedupe_key:
            raise ValueError("topic y dedupe_key son obligatorios")
        encoded = self._encode_payload(payload)
        with self._lock:
            self.connection.execute(
                """INSERT INTO outbox(topic,payload,dedupe_key) VALUES (?,?,?)
                ON CONFLICT(dedupe_key) DO UPDATE SET topic=excluded.topic,payload=excluded.payload,
                created_at=CURRENT_TIMESTAMP,sent_at=NULL,attempt_count=0,next_attempt_at=NULL,
                last_error=NULL,discarded_at=NULL""",
                (topic, encoded, dedupe_key),
            )
            row = self.connection.execute(
                "SELECT id FROM outbox WHERE dedupe_key=?", (dedupe_key,)
            ).fetchone()
            self.connection.commit()
            if row is None:
                raise RuntimeError("no se pudo guardar el último estado")
            return int(row[0])

    def pending(
        self,
        topics: tuple[str, ...] | None = None,
        *,
        limit: int = 100,
    ) -> list[tuple[int, str, dict[str, Any]]]:
        if not 1 <= limit <= 1000:
            raise ValueError("limit debe estar entre 1 y 1000")
        with self._lock:
            parameters: list[Any] = []
            topic_filter = ""
            if topics:
                topic_filter = f" AND topic IN ({','.join('?' for _ in topics)})"
                parameters.extend(topics)
            parameters.append(limit)
            rows = self.connection.execute(
                f"""SELECT id,topic,payload FROM outbox
                WHERE sent_at IS NULL AND discarded_at IS NULL
                  AND (next_attempt_at IS NULL OR next_attempt_at <= CURRENT_TIMESTAMP)
                  {topic_filter}
                ORDER BY id LIMIT ?""",
                parameters,
            ).fetchall()
            valid: list[tuple[int, str, dict[str, Any]]] = []
            for row in rows:
                try:
                    payload = json.loads(row[2])
                    if not isinstance(payload, dict):
                        raise ValueError("payload no es objeto")
                except (json.JSONDecodeError, ValueError, TypeError) as exc:
                    self._mark_failed_locked(int(row[0]), f"invalid_payload:{type(exc).__name__}")
                    continue
                valid.append((int(row[0]), str(row[1]), payload))
            self.connection.commit()
            return valid

    def mark_sent(self, event_id: int) -> None:
        with self._lock:
            self.connection.execute(
                """UPDATE outbox SET sent_at=CURRENT_TIMESTAMP,next_attempt_at=NULL,
                last_error=NULL WHERE id=? AND discarded_at IS NULL""",
                (event_id,),
            )
            self.connection.commit()

    def mark_retry(self, event_id: int, error: str, retry_seconds: float) -> None:
        with self._lock:
            row = self.connection.execute(
                "SELECT attempt_count FROM outbox WHERE id=? AND sent_at IS NULL",
                (event_id,),
            ).fetchone()
            if row is None:
                return
            delay = max(1, min(3600, int(retry_seconds) * (2 ** min(int(row[0]), 9))))
            self.connection.execute(
                """UPDATE outbox SET attempt_count=attempt_count+1,last_error=?,
                next_attempt_at=datetime('now', ?) WHERE id=? AND sent_at IS NULL""",
                (error[:240], f"+{delay} seconds", event_id),
            )
            self.connection.commit()

    def prune_outbox(self, sent_retention_days: int = 30) -> int:
        days = max(1, min(365, int(sent_retention_days)))
        with self._lock:
            cursor = self.connection.execute(
                "DELETE FROM outbox WHERE sent_at < datetime('now', ?)",
                (f"-{days} days",),
            )
            self.connection.commit()
            return int(cursor.rowcount)

    def mark_failed(self, event_id: int, error: str) -> None:
        with self._lock:
            self._mark_failed_locked(event_id, error)
            self.connection.commit()

    def close(self) -> None:
        with self._lock:
            self.connection.close()

    def _mark_failed_locked(self, event_id: int, error: str) -> None:
        self.connection.execute(
            """UPDATE outbox SET attempt_count=attempt_count+1,last_error=?,
            discarded_at=CURRENT_TIMESTAMP WHERE id=? AND sent_at IS NULL""",
            (error[:240], event_id),
        )

    def _migrate_outbox(self) -> None:
        columns = {
            row[1]
            for row in self.connection.execute("PRAGMA table_info(outbox)").fetchall()
        }
        migrations = {
            "dedupe_key": "ALTER TABLE outbox ADD COLUMN dedupe_key TEXT",
            "attempt_count": "ALTER TABLE outbox ADD COLUMN attempt_count INTEGER NOT NULL DEFAULT 0",
            "next_attempt_at": "ALTER TABLE outbox ADD COLUMN next_attempt_at TEXT",
            "last_error": "ALTER TABLE outbox ADD COLUMN last_error TEXT",
            "discarded_at": "ALTER TABLE outbox ADD COLUMN discarded_at TEXT",
        }
        for column, statement in migrations.items():
            if column not in columns:
                self.connection.execute(statement)
        self.connection.execute("DROP INDEX IF EXISTS idx_outbox_dedupe_key")
        self.connection.execute(
            "CREATE UNIQUE INDEX idx_outbox_dedupe_key ON outbox(dedupe_key)"
        )
        self.connection.execute(
            "CREATE INDEX IF NOT EXISTS idx_outbox_delivery ON outbox(topic,sent_at,discarded_at,next_attempt_at,id)"
        )
        self.connection.execute(
            "CREATE INDEX IF NOT EXISTS idx_outbox_sent ON outbox(sent_at)"
        )

    @staticmethod
    def _encode_payload(payload: dict[str, Any]) -> str:
        encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True)
        if len(encoded.encode("utf-8")) > 64 * 1024:
            raise ValueError("payload excede 64 KiB")
        return encoded
