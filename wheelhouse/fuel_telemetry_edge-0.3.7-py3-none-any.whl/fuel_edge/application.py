"""Orquestador nativo del RPi para validación, control y persistencia local."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from threading import RLock
from time import monotonic
from typing import Callable, Protocol

from .domain import AuditRecord, EdgeEvent, EdgeState, FuelEdgeMachine
from .rfid import (
    EquipmentEvidence,
    RfidAuthorizationService,
    RfidCredential,
    RfidReaderError,
)
from .service import FuelEdgeService
from .nfc_enrollment import NfcEnrollmentCoordinator
from .validator_link import (
    CredentialPresenceUpdate,
    EquipmentPresenceUpdate,
    RemoteEquipmentObservation,
    RemoteRfidReader,
    ValidatorDecision,
    ValidatorPresentation,
    ValidatorTransport,
    ValidatorTransportError,
)


@dataclass(frozen=True, slots=True)
class EquipmentAuthorizationRecord:
    equipment_id: str
    active: bool = True
    assignment_valid_until: datetime | None = None


class AuthorizationDirectory(Protocol):
    def resolve_equipment(
        self,
        operator_id: str,
        observation: RemoteEquipmentObservation | None,
    ) -> EquipmentEvidence | None: ...


@dataclass(slots=True)
class MemoryAuthorizationDirectory:
    """Directorio local del RPi; nunca confía la asociación al validador."""

    equipment: dict[str, EquipmentAuthorizationRecord] = field(default_factory=dict)
    associations: set[tuple[str, str]] = field(default_factory=set)

    def resolve_equipment(
        self,
        operator_id: str,
        observation: RemoteEquipmentObservation | None,
    ) -> EquipmentEvidence | None:
        if observation is None:
            return None
        record = self.equipment.get(observation.equipment_id)
        return EquipmentEvidence(
            equipment_id=observation.equipment_id,
            active=record.active if record is not None else False,
            present=observation.present,
            authenticated=observation.authenticated,
            association_active=(
                record is not None
                and (operator_id, observation.equipment_id) in self.associations
            ),
            assignment_valid_until=(
                record.assignment_valid_until if record is not None else None
            ),
        )


@dataclass(slots=True)
class FuelEdgeApplication:
    """Une el validador remoto con la máquina segura que corre en el RPi."""

    control: FuelEdgeService
    rfid: RfidAuthorizationService
    transport: ValidatorTransport
    directory: AuthorizationDirectory
    validator_id: str
    proof_timeout_seconds: float = 5.0
    nfc_enrollment: NfcEnrollmentCoordinator | None = None
    on_equipment_observation: Callable[[str, int], None] | None = None
    point_available: Callable[[], bool] = lambda: True
    control_chain_healthy: Callable[[], bool] = lambda: True
    _lock: RLock = field(default_factory=RLock, init=False)
    _processed_sessions: set[str] = field(default_factory=set, init=False)
    _session_order: deque[str] = field(default_factory=deque, init=False)
    _active_validator_session: str | None = field(default=None, init=False)
    _active_equipment_id: str | None = field(default=None, init=False)
    _active_credential_id: str | None = field(default=None, init=False)
    _credential_last_seen: float | None = field(default=None, init=False)
    monotonic_clock: Callable[[], float] = monotonic

    @property
    def machine(self) -> FuelEdgeMachine:
        return self.control.machine

    def process_presentation(
        self, presentation: ValidatorPresentation
    ) -> ValidatorDecision:
        """Procesa una conversación completa y responde al validador."""

        with self._lock:
            if (
                presentation.equipment is not None
                and presentation.equipment.rssi is not None
                and presentation.equipment.module_id is not None
                and self.on_equipment_observation is not None
            ):
                self.on_equipment_observation(
                    presentation.equipment.module_id,
                    presentation.equipment.rssi,
                )
            if presentation.validator_id != self.validator_id:
                return self._publish_rejection(presentation, "validator_not_assigned")
            if presentation.session_id in self._processed_sessions:
                return self._publish_rejection(presentation, "replayed_session")
            self._remember_session(presentation.session_id)

            if self.machine.state is not EdgeState.LOCKED:
                return self._publish_rejection(presentation, "point_busy")

            if self.nfc_enrollment is not None:
                try:
                    enrollment_decision = self.nfc_enrollment.process_presentation(
                        presentation,
                        self.transport,
                        self.proof_timeout_seconds,
                    )
                except (OSError, TimeoutError, ValueError):
                    enrollment_decision = ValidatorDecision(
                        validator_id=presentation.validator_id,
                        session_id=presentation.session_id,
                        allowed=False,
                        state=str(self.machine.state),
                        reason="enrollment_local_error",
                    )
                if enrollment_decision is not None:
                    self._publish(enrollment_decision)
                    return enrollment_decision

            if not self.machine.validator_online:
                self.control.apply(
                    EdgeEvent.VALIDATOR_LINK_RESTORED,
                    validator_id=presentation.validator_id,
                )

            reader = RemoteRfidReader(
                transport=self.transport,
                validator_id=presentation.validator_id,
                session_id=presentation.session_id,
                timeout_seconds=self.proof_timeout_seconds,
            )
            try:
                outcome = self.rfid.handle_presentation(
                    self.control,
                    reader,
                    equipment_resolver=lambda credential: self._resolve_equipment(
                        credential, presentation.equipment
                    ),
                    point_available=self.point_available(),
                    control_chain_healthy=self.control_chain_healthy(),
                )
            except RfidReaderError:
                self._mark_validator_offline(presentation.validator_id)
                return self._publish_rejection(
                    presentation, "validator_link_error", mark_offline=False
                )
            except RuntimeError:
                return self._publish_rejection(
                    presentation, "local_persistence_error", mark_offline=False
                )
            if outcome.authorized:
                self._active_validator_session = presentation.session_id
                self._active_equipment_id = self.machine.equipment_id
                self._active_credential_id = outcome.authentication.credential_id
                self._credential_last_seen = self.monotonic_clock()
                decision = ValidatorDecision(
                    validator_id=presentation.validator_id,
                    session_id=presentation.session_id,
                    allowed=True,
                    state=str(self.machine.state),
                    transaction_id=self.machine.transaction_id,
                )
            else:
                reason = "no_credential"
                if outcome.audit_record is not None:
                    reason = str(outcome.audit_record.metadata.get("reason", "denied"))
                elif outcome.authentication.reason is not None:
                    reason = str(outcome.authentication.reason)
                decision = ValidatorDecision(
                    validator_id=presentation.validator_id,
                    session_id=presentation.session_id,
                    allowed=False,
                    state=str(self.machine.state),
                    reason=reason,
                )
            try:
                self._publish(decision)
            except ValidatorTransportError:
                self._mark_validator_offline(presentation.validator_id)
                raise
            return decision

    def process_equipment_presence(
        self, update: EquipmentPresenceUpdate
    ) -> AuditRecord | None:
        """Aplica sólo una pérdida BLE correlacionada y ya confirmada 20 s."""

        with self._lock:
            if update.validator_id != self.validator_id:
                return None
            if update.session_id != self._active_validator_session:
                return None
            if update.equipment_id != self._active_equipment_id:
                return None
            if update.present and update.authenticated:
                return None
            if update.lost_for_seconds < self.machine.config.ble_loss_seconds:
                return None
            if self.machine.state not in {EdgeState.AUTHORIZED, EdgeState.DISPENSING}:
                return None
            record = self.control.apply(
                EdgeEvent.BLE_LOST,
                reason="ble_presence_lost",
                validator_id=update.validator_id,
                session_id=update.session_id,
                module_id=update.module_id,
                equipment_id=update.equipment_id,
                lost_for_seconds=update.lost_for_seconds,
                last_rssi=update.rssi,
                battery_percent=update.battery_percent,
            )
            self._clear_active_session()
            return record

    def process_credential_presence(
        self, update: CredentialPresenceUpdate
    ) -> AuditRecord | None:
        """Mantiene el permiso RFID y corta ante ausencia o cambio de llave."""

        with self._lock:
            if update.validator_id != self.validator_id:
                return None
            if update.session_id != self._active_validator_session:
                return None
            if self.machine.state not in {EdgeState.AUTHORIZED, EdgeState.DISPENSING}:
                return None
            credential_changed = update.credential_id != self._active_credential_id
            if update.present and update.authenticated and not credential_changed:
                self._credential_last_seen = self.monotonic_clock()
                return None
            if (
                not credential_changed
                and update.absent_for_milliseconds
                < self.machine.config.nfc_debounce_milliseconds
            ):
                return None
            reason = "credential_changed" if credential_changed else "nfc_removed"
            record = self.control.apply(
                EdgeEvent.NFC_REMOVED,
                reason=reason,
                validator_id=update.validator_id,
                session_id=update.session_id,
                credential_id=update.credential_id,
                absent_for_milliseconds=update.absent_for_milliseconds,
            )
            self._clear_active_session()
            return record

    def check_credential_presence_timeout(self) -> AuditRecord | None:
        """Corta si desaparecen los heartbeats que demuestran la llave presente."""

        with self._lock:
            if self.machine.state not in {EdgeState.AUTHORIZED, EdgeState.DISPENSING}:
                return None
            if self._active_validator_session is None or self._credential_last_seen is None:
                return None
            elapsed_ms = int(
                (self.monotonic_clock() - self._credential_last_seen) * 1000
            )
            if elapsed_ms < self.machine.config.nfc_presence_timeout_milliseconds:
                return None
            record = self.control.apply(
                EdgeEvent.NFC_REMOVED,
                reason="credential_presence_timeout",
                validator_id=self.validator_id,
                session_id=self._active_validator_session,
                credential_id=self._active_credential_id,
                absent_for_milliseconds=elapsed_ms,
            )
            self._clear_active_session()
            return record

    def process_validator_disconnect(self) -> None:
        """Corta de inmediato al confirmarse la caída del enlace del validador."""

        with self._lock:
            self._mark_validator_offline(self.validator_id)
            if self.machine.state not in {EdgeState.AUTHORIZED, EdgeState.DISPENSING}:
                self._clear_active_session()

    def _resolve_equipment(
        self,
        credential: RfidCredential,
        observation: RemoteEquipmentObservation | None,
    ) -> EquipmentEvidence | None:
        return self.directory.resolve_equipment(credential.operator_id, observation)

    def _publish_rejection(
        self,
        presentation: ValidatorPresentation,
        reason: str,
        *,
        mark_offline: bool = True,
    ) -> ValidatorDecision:
        decision = ValidatorDecision(
            validator_id=presentation.validator_id,
            session_id=presentation.session_id,
            allowed=False,
            state=str(self.machine.state),
            reason=reason,
        )
        try:
            self._publish(decision)
        except ValidatorTransportError:
            if mark_offline:
                self._mark_validator_offline(presentation.validator_id)
            raise
        return decision

    def _publish(self, decision: ValidatorDecision) -> None:
        try:
            self.transport.publish_decision(decision)
        except ValidatorTransportError:
            raise
        except Exception as exc:
            raise ValidatorTransportError("no se pudo responder al validador") from exc

    def _mark_validator_offline(self, validator_id: str) -> None:
        if not self.machine.validator_online:
            return
        try:
            self.control.apply(
                EdgeEvent.VALIDATOR_LINK_LOST,
                validator_id=validator_id,
            )
        except (RuntimeError, ValueError):
            pass

    def _clear_active_session(self) -> None:
        self._active_validator_session = None
        self._active_equipment_id = None
        self._active_credential_id = None
        self._credential_last_seen = None

    def _remember_session(self, session_id: str) -> None:
        self._processed_sessions.add(session_id)
        self._session_order.append(session_id)
        while len(self._session_order) > 512:
            expired = self._session_order.popleft()
            self._processed_sessions.discard(expired)
